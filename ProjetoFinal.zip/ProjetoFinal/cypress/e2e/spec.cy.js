describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://seubarriga.wcaquino.me/login')
  })
})