/// <reference types="cypress"/>
describe('Teste NAVBAR', () => {
    const conta= 8383
    it.only('Adicionar uma Conta', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        //Criando uma conta
        cy.get('.dropdown-toggle').click()
        cy.get('.dropdown-menu > :nth-child(1) > a').click()
        cy.get('#nome').type(`${conta}`)
        cy.get('.btn').click()
        

    });

    it('Adicionar uma Conta ja existente', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        //Criando uma conta ja existente
        cy.get('.dropdown-toggle').click()
        cy.get('.dropdown-menu > :nth-child(1) > a').click()
        cy.get('#nome').type(`${conta}`)
        cy.get('.btn').click()
        cy.get('.alert').should('contain',"Já existe uma conta com esse nome!")
        

    });

    it('Listando conta', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        //listando conta
        cy.get('.dropdown-toggle').click()
        cy.get('.dropdown-menu > :nth-child(2) > a').click()
        cy.get('tbody > tr > :nth-child(1)').should('contain',(`${conta}`))

    });

    it('Editando conta', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        //editando a conta
        cy.get('.dropdown-toggle').click()
        cy.get('.dropdown-menu > :nth-child(2) > a').click()
        cy.get('[href="/editarConta?id=2057901"] > .glyphicon').click()
        cy.get('#nome').type((`${conta}`)+"9090")
        cy.get('.btn').click()
        cy.get('.alert').should('contain',"Conta alterada com sucesso!")

    });

    it('Removendo conta', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        //Removendo conta
        cy.get('.dropdown-toggle').click()
        cy.get('.dropdown-menu > :nth-child(2) > a').click()
        cy.get('[href="/removerConta?id=2057891"] > .glyphicon').should('contein',(`${conta}`)).click()
        cy.get('.alert').should('contains',"Conta removida com sucesso!")
    
    });
    it.only('Criar movimentação', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')
        
        cy.get(':nth-child(3) > a').click()
        cy.get('#tipo').select(1)
        cy.get('#data_transacao').type("25/10/2015")
        cy.get('#data_pagamento').type("26/11/2016")
        cy.get('#descricao').type("pagamento feito")
        cy.get('#interessado').type("amigo")
        cy.get('#valor').type("2000")
        cy.get('#conta').select(`${conta}`)
        cy.get('#status_pendente').click()
        cy.get('.btn').click()
              
    })
    it.only('Sair', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')
        
        cy.get(':nth-child(5) > a').click()
              
    })

    

    


});