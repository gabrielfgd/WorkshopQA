/// <reference types="cypress"/>

describe('Teste de login', () => {
    it('Deve realizar o login com sucesso!', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        
    });

    it('Validando login incorreto', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengaol@gmail.com")
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.alert').should('contain','Problemas com o login do usuário')

        
    });

    it('Validar senha incorreta', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get('#email').type("titemengao@gmail.com")
        cy.get('#senha').type("1234567")
        cy.get('.btn').click()
        cy.get('.alert').should('contain','Problemas com o login do usuário')
        

        
    });
});