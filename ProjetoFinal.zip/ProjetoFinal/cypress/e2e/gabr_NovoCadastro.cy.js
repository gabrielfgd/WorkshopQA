/// <reference types="cypress"/>

describe('Teste de novo usuario', () => {
    function getRndInteger(min, max) {
        return Math.floor(Math.random() * (max - min) ) + min;
      }
      const valor= getRndInteger(0,1000)
    it('Deve realizar o novo cadastro com sucesso', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get(':nth-child(2) > a').click()
        cy.get('#nome').type("gabigol")
        cy.get('#email').type(`gabigol201${valor}@gmail.com`)
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.navbar-brand').should('contain','Seu Barriga')

        
    });

    it('validando um email ja utilizado', () => {
        cy.visit("https://seubarriga.wcaquino.me/login")
        cy.get(':nth-child(2) > a').click()
        cy.get('#nome').type("gabigol")
        cy.get('#email').type(`gabigol2019@gmail.com`)
        cy.get('#senha').type("123456")
        cy.get('.btn').click()
        cy.get('.alert').should('contain',"Endereço de email já utilizado")
        

        
    });
});